# Examples

```
$ python list_apps.py <YOUR_AK> <YOUR_SK>
```
